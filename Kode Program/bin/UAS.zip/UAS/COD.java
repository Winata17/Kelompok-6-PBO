package UAS;

public class COD implements MetodePembayaran {
    public double hitungTotal(double totalAwal) {
        return totalAwal; // Tanpa diskon
    }
}
