package UAS;

public class TransferBank implements MetodePembayaran {
    public double hitungTotal(double totalAwal) {
        return totalAwal * 0.90; // Diskon 10%
    }
}
