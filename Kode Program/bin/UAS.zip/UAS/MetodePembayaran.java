package UAS;

public interface MetodePembayaran {
    double hitungTotal(double totalAwal);
}