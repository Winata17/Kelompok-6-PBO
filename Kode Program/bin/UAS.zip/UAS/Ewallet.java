package UAS;

public class Ewallet implements MetodePembayaran {
    public double hitungTotal(double totalAwal) {
        return totalAwal * 0.95; // Diskon 5%
    }
}
